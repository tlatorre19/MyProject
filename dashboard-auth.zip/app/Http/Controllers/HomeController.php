<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Item;

class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function home()
    {
        return view('home');
    }

    public function charts()
    {
        return view('charts.charts');
    }

    public function iconmenu()
    {
        return view('icon-menu');
    }

    public function forms()
    {
        $items = Item::latest()->get();
        return view('forms', compact('items'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'date' => 'required|date',
            'type' => 'required',
            'reporter_name' => 'required',
            'contact_no' => 'required',
        ]);

        Item::create([
            'user_id' => auth()->id(),
            'name' => $request->name,
            'description' => $request->description,
            'date' => $request->date,
            'type' => $request->type,
            'status' => 'Pending',
            'reporter_name' => $request->reporter_name,
            'contact_no' => $request->contact_no,
        ]);

        return redirect()->route('forms')->with('success', 'Item reported successfully.');
    }

    public function edit(Item $item)
    {
        return view('items.edit', compact('item'));
    }

    public function update(Request $request, Item $item)
    {
        $request->validate([
            'name' => 'required',
            'description' => 'required',
            'date' => 'required|date',
            'type' => 'required',
            'status' => 'required',        // ✅ added
            'reporter_name' => 'required',
            'contact_no' => 'required',
        ]);

        $item->update($request->all());

        return redirect()->route('forms')->with('success', 'Item updated successfully.');
    }

    public function destroy(Item $item)
    {
        $item->delete();

        return redirect()->route('forms')->with('success', 'Item deleted successfully.');
    }
}