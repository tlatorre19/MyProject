@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Lost & Found Management System</h2>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            Report Lost or Found Item
        </div>
        <div class="card-body">
            <form action="{{ route('forms.store') }}" method="POST">
                @csrf

                <div class="mb-3">
                    <label>Item Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Description</label>
                    <textarea name="description" class="form-control" required></textarea>
                </div>

                <div class="mb-3">
                    <label>Date Lost/Found</label>
                    <input type="date" name="date" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Type</label>
                    <select name="type" class="form-select" required>
                        <option value="">Select Type</option>
                        <option value="Lost">Lost</option>
                        <option value="Found">Found</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Reporter Name</label>
                    <input type="text" name="reporter_name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Contact No.</label>
                    <input type="text" name="contact_no" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-success">Submit</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-dark text-white">
            Reported Items
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Status</th> 
                        <th>Reporter Name</th>
                        <th>Contact No.</th>
                        <th>Match</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($items as $item)
                        @php
                            $match = $items
                                ->where('name', $item->name)
                                ->where('type', '!=', $item->type)
                                ->first();
                        @endphp
                        <tr>
                            <td>{{ $item->name }}</td>
                            <td>{{ $item->description }}</td>
                            <td>{{ $item->date }}</td>
                            <td>
                                <span class="badge bg-{{ $item->type == 'Lost' ? 'danger' : 'success' }}">
                                    {{ $item->type }}
                                </span>
                            </td>
                            <td>  {{-- ✅ added --}}
                                <span class="badge bg-{{ $item->status == 'Pending' ? 'warning' : 'success' }}">
                                    {{ $item->status }}
                                </span>
                            </td>
                            <td>{{ $item->reporter_name }}</td>
                            <td>{{ $item->contact_no }}</td>
                            <td>
                                @if($match)
                                    <span class="badge bg-success">Possible Match</span>
                                @else
                                    -
                                @endif
                            </td>
                            <td>
                                <a href="{{ route('forms.edit', $item->id) }}"
                                   class="btn btn-warning btn-sm">Edit</a>

                                <form action="{{ route('forms.destroy', $item->id) }}"
                                      method="POST"
                                      class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger btn-sm"
                                            onclick="return confirm('Are you sure?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="9" class="text-center">No items reported yet.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection