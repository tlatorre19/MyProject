

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Edit Item</h2>

    <div class="card">
        <div class="card-header bg-primary text-white">
            Edit Reported Item
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('forms.update', $item->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label>Item Name</label>
                    <input type="text" name="name" class="form-control"
                           value="<?php echo e($item->name); ?>" required>
                </div>

                <div class="mb-3">
                    <label>Description</label>
                    <textarea name="description" class="form-control" required><?php echo e($item->description); ?></textarea>
                </div>

                <div class="mb-3">
                    <label>Date Lost/Found</label>
                    <input type="date" name="date" class="form-control"
                           value="<?php echo e($item->date); ?>" required>
                </div>

                <div class="mb-3">
                    <label>Type</label>
                    <select name="type" class="form-select" required>
                        <option value="">Select Type</option>
                        <option value="Lost" <?php echo e($item->type == 'Lost' ? 'selected' : ''); ?>>Lost</option>
                        <option value="Found" <?php echo e($item->type == 'Found' ? 'selected' : ''); ?>>Found</option>
                    </select>
                </div>

                <div class="mb-3">  
                    <label>Status</label>
                    <select name="status" class="form-select" required>
                        <option value="Pending" <?php echo e($item->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="Resolved" <?php echo e($item->status == 'Resolved' ? 'selected' : ''); ?>>Resolved</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Reporter Name</label>
                    <input type="text" name="reporter_name" class="form-control"
                           value="<?php echo e($item->reporter_name); ?>" required>
                </div>

                <div class="mb-3">
                    <label>Contact No.</label>
                    <input type="text" name="contact_no" class="form-control"
                           value="<?php echo e($item->contact_no); ?>" required>
                </div>

                <a href="<?php echo e(route('forms')); ?>" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-success">Update</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\dashboard-auth\resources\views\items\edit.blade.php ENDPATH**/ ?>