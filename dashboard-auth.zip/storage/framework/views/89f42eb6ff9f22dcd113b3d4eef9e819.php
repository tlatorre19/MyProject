

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Add Category</h2>

    <div class="card">
        <div class="card-header bg-primary text-white">
            New Category
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('category.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label>Category</label>
                    <select name="name" class="form-select" required>
                        <option value="">Select Category</option>

                        <optgroup label="Electronics">
                            <option value="Phones">Phones</option>
                            <option value="Laptops">Laptops</option>
                            <option value="Tablets">Tablets</option>
                            <option value="Earphones">Earphones</option>
                            <option value="Chargers">Chargers</option>
                        </optgroup>

                        <optgroup label="Clothing & Accessories">
                            <option value="Shirts">Shirts</option>
                            <option value="Pants">Pants</option>
                            <option value="Jackets">Jackets</option>
                            <option value="Hats">Hats</option>
                            <option value="Bags">Bags</option>
                        </optgroup>

                        <optgroup label="Documents">
                            <option value="ID Cards">ID Cards</option>
                            <option value="Passports">Passports</option>
                            <option value="Licenses">Licenses</option>
                            <option value="Cards">Cards</option>
                        </optgroup>

                        <optgroup label="Jewelry & Valuables">
                            <option value="Rings">Rings</option>
                            <option value="Necklaces">Necklaces</option>
                            <option value="Watches">Watches</option>
                            <option value="Bracelets">Bracelets</option>
                        </optgroup>

                        <optgroup label="School Supplies">
                            <option value="Books">Books</option>
                            <option value="Notebooks">Notebooks</option>
                            <option value="Pens">Pens</option>
                            <option value="Calculators">Calculators</option>
                        </optgroup>

                        <optgroup label="Keys">
                            <option value="House Keys">House Keys</option>
                            <option value="Car Keys">Car Keys</option>
                            <option value="Padlocks">Padlocks</option>
                        </optgroup>

                        <optgroup label="Wallets & Purses">
                            <option value="Wallets">Wallets</option>
                            <option value="Purses">Purses</option>
                            <option value="Coin Purses">Coin Purses</option>
                        </optgroup>

                        <optgroup label="Sports Equipment">
                            <option value="Balls">Balls</option>
                            <option value="Rackets">Rackets</option>
                            <option value="Helmets">Helmets</option>
                            <option value="Gloves">Gloves</option>
                        </optgroup>

                        <optgroup label="Others">
                            <option value="Others">Others</option>
                        </optgroup>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Description</label>
                    <textarea name="description" class="form-control"></textarea>
                </div>

                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-success">Save</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\dashboard-auth\resources\views/category/create.blade.php ENDPATH**/ ?>