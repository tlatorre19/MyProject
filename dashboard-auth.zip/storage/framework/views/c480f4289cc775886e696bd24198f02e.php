

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Edit Category</h2>

    <div class="card">
        <div class="card-header bg-primary text-white">
            Edit Category
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('category.update', $category->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label>Category Name</label>
                    <select name="name" class="form-select" required>
                        <option value="">Select Category</option>

                        <optgroup label="Electronics">
                            <option value="Phones" <?php echo e($category->name == 'Phones' ? 'selected' : ''); ?>>Phones</option>
                            <option value="Laptops" <?php echo e($category->name == 'Laptops' ? 'selected' : ''); ?>>Laptops</option>
                            <option value="Tablets" <?php echo e($category->name == 'Tablets' ? 'selected' : ''); ?>>Tablets</option>
                            <option value="Earphones" <?php echo e($category->name == 'Earphones' ? 'selected' : ''); ?>>Earphones</option>
                            <option value="Chargers" <?php echo e($category->name == 'Chargers' ? 'selected' : ''); ?>>Chargers</option>
                        </optgroup>

                        <optgroup label="Clothing & Accessories">
                            <option value="Shirts" <?php echo e($category->name == 'Shirts' ? 'selected' : ''); ?>>Shirts</option>
                            <option value="Pants" <?php echo e($category->name == 'Pants' ? 'selected' : ''); ?>>Pants</option>
                            <option value="Jackets" <?php echo e($category->name == 'Jackets' ? 'selected' : ''); ?>>Jackets</option>
                            <option value="Hats" <?php echo e($category->name == 'Hats' ? 'selected' : ''); ?>>Hats</option>
                            <option value="Bags" <?php echo e($category->name == 'Bags' ? 'selected' : ''); ?>>Bags</option>
                        </optgroup>

                        <optgroup label="Documents">
                            <option value="ID Cards" <?php echo e($category->name == 'ID Cards' ? 'selected' : ''); ?>>ID Cards</option>
                            <option value="Passports" <?php echo e($category->name == 'Passports' ? 'selected' : ''); ?>>Passports</option>
                            <option value="Licenses" <?php echo e($category->name == 'Licenses' ? 'selected' : ''); ?>>Licenses</option>
                            <option value="Cards" <?php echo e($category->name == 'Cards' ? 'selected' : ''); ?>>Cards</option>
                        </optgroup>

                        <optgroup label="Jewelry & Valuables">
                            <option value="Rings" <?php echo e($category->name == 'Rings' ? 'selected' : ''); ?>>Rings</option>
                            <option value="Necklaces" <?php echo e($category->name == 'Necklaces' ? 'selected' : ''); ?>>Necklaces</option>
                            <option value="Watches" <?php echo e($category->name == 'Watches' ? 'selected' : ''); ?>>Watches</option>
                            <option value="Bracelets" <?php echo e($category->name == 'Bracelets' ? 'selected' : ''); ?>>Bracelets</option>
                        </optgroup>

                        <optgroup label="School Supplies">
                            <option value="Books" <?php echo e($category->name == 'Books' ? 'selected' : ''); ?>>Books</option>
                            <option value="Notebooks" <?php echo e($category->name == 'Notebooks' ? 'selected' : ''); ?>>Notebooks</option>
                            <option value="Pens" <?php echo e($category->name == 'Pens' ? 'selected' : ''); ?>>Pens</option>
                            <option value="Calculators" <?php echo e($category->name == 'Calculators' ? 'selected' : ''); ?>>Calculators</option>
                        </optgroup>

                        <optgroup label="Keys">
                            <option value="House Keys" <?php echo e($category->name == 'House Keys' ? 'selected' : ''); ?>>House Keys</option>
                            <option value="Car Keys" <?php echo e($category->name == 'Car Keys' ? 'selected' : ''); ?>>Car Keys</option>
                            <option value="Padlocks" <?php echo e($category->name == 'Padlocks' ? 'selected' : ''); ?>>Padlocks</option>
                        </optgroup>

                        <optgroup label="Wallets & Purses">
                            <option value="Wallets" <?php echo e($category->name == 'Wallets' ? 'selected' : ''); ?>>Wallets</option>
                            <option value="Purses" <?php echo e($category->name == 'Purses' ? 'selected' : ''); ?>>Purses</option>
                            <option value="Coin Purses" <?php echo e($category->name == 'Coin Purses' ? 'selected' : ''); ?>>Coin Purses</option>
                        </optgroup>

                        <optgroup label="Sports Equipment">
                            <option value="Balls" <?php echo e($category->name == 'Balls' ? 'selected' : ''); ?>>Balls</option>
                            <option value="Rackets" <?php echo e($category->name == 'Rackets' ? 'selected' : ''); ?>>Rackets</option>
                            <option value="Helmets" <?php echo e($category->name == 'Helmets' ? 'selected' : ''); ?>>Helmets</option>
                            <option value="Gloves" <?php echo e($category->name == 'Gloves' ? 'selected' : ''); ?>>Gloves</option>
                        </optgroup>

                        <optgroup label="Others">
                            <option value="Others" <?php echo e($category->name == 'Others' ? 'selected' : ''); ?>>Others</option>
                        </optgroup>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Description</label>
                    <textarea name="description" class="form-control"><?php echo e($category->description); ?></textarea>
                </div>

                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-success">Update</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\dashboard-auth\resources\views\category\edit.blade.php ENDPATH**/ ?>