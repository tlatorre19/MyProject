

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Lost & Found Management System</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            Report Lost or Found Item
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('forms.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label>Item Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Description</label>
                    <textarea name="description" class="form-control" required></textarea>
                </div>

                <div class="mb-3">
                    <label>Date Lost/Found</label>
                    <input type="date" name="date" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Type</label>
                    <select name="type" class="form-select" required>
                        <option value="">Select Type</option>
                        <option value="Lost">Lost</option>
                        <option value="Found">Found</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Reporter Name</label>
                    <input type="text" name="reporter_name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Contact No.</label>
                    <input type="text" name="contact_no" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-success">Submit</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-dark text-white">
            Reported Items
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Status</th> 
                        <th>Reporter Name</th>
                        <th>Contact No.</th>
                        <th>Match</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $match = $items
                                ->where('name', $item->name)
                                ->where('type', '!=', $item->type)
                                ->first();
                        ?>
                        <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->description); ?></td>
                            <td><?php echo e($item->date); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($item->type == 'Lost' ? 'danger' : 'success'); ?>">
                                    <?php echo e($item->type); ?>

                                </span>
                            </td>
                            <td>  
                                <span class="badge bg-<?php echo e($item->status == 'Pending' ? 'warning' : 'success'); ?>">
                                    <?php echo e($item->status); ?>

                                </span>
                            </td>
                            <td><?php echo e($item->reporter_name); ?></td>
                            <td><?php echo e($item->contact_no); ?></td>
                            <td>
                                <?php if($match): ?>
                                    <span class="badge bg-success">Possible Match</span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('forms.edit', $item->id)); ?>"
                                   class="btn btn-warning btn-sm">Edit</a>

                                <form action="<?php echo e(route('forms.destroy', $item->id)); ?>"
                                      method="POST"
                                      class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm"
                                            onclick="return confirm('Are you sure?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center">No items reported yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\dashboard-auth\resources\views\forms.blade.php ENDPATH**/ ?>